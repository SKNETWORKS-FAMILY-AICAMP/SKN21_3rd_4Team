The :mod:`!concurrent` package
==============================

This package contains the following modules:

* :mod:`concurrent.futures` -- Launching parallel tasks
* :mod:`concurrent.interpreters` -- Multiple interpreters in the same process
